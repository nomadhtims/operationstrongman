# Strongman Peak PWA

A lightweight, offline-capable progressive web app built around the 31 October 2026 Log + Deadlift competition peak.

## Included
- Handover week using the current coach's key log/deadlift prescriptions.
- Four progressive training weeks plus competition-week taper.
- Log target: 115 kg current PB → 120 kg goal.
- Deadlift target: 260 kg current PB → 280 kg goal.
- 4-day layout: Log/Upper, Deadlift/Back, Legs, Log+Deadlift Support.
- Set-by-set weight, reps and RPE logging.
- Readiness tracking.
- Competition countdown and training-best display.
- Offline caching after first load.
- Local browser storage plus JSON export/import.
- Responsive layout designed to work as one-column on a phone cover screen and two-column on larger/unfolded screens.

## Run locally
Because service workers require HTTP/HTTPS, do not just double-click `index.html` if you want offline/install features.

From this folder:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`.

## Host it
Any static host works: GitHub Pages, Cloudflare Pages, Netlify, Vercel, or similar. Upload/deploy the contents of this folder with `index.html` at the site root.

Once served over HTTPS, open the site in Chrome on Android and use **Install app / Add to Home screen** if the automatic Install button is not shown.

## Data
Training data is local to the browser/device. Use **Data → Export JSON** to back it up. Clearing site/browser data will otherwise remove the log.

## Programming note
The optional 117.5 kg log and 270 kg deadlift singles are explicitly conditional on the preceding heavy single moving within the programmed RPE cap. The app intentionally does not schedule 120 kg log or 280 kg deadlift in training before competition day.
